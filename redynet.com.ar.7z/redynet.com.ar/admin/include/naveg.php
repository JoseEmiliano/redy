<table width="140" border="0" cellspacing="1" cellpadding="0" bgcolor="#999999">
<tr> 
<td width="140" style="padding: 5px" class="textolistado" bgcolor="#FFFFFF"> 
<a href="home.php" class="textolistado" style="text-decoration: none">HOME</a></td>
</tr>
</table>
<br>

<table width="140" border="0" cellspacing="1" cellpadding="0" bgcolor="#999999">
	<tr> 
		<td width="140" style="padding: 5px" class="textolistado" bgcolor="#CCCCCC">MODULO DE ADMINISTRACION</td>
	</tr>

	<tr> 
		<td width="140" style="padding: 5px" class="textolistado" bgcolor="#F7F7F7"><a href="listado_administradores.php" class="textolistado" style="text-decoration: none">ADMINISTRADORES</a></td>
	</tr>
</table>
<br>

<table width="140" border="0" cellspacing="1" cellpadding="0" bgcolor="#999999">
	<tr> 
		<td width="140" style="padding: 5px" class="textolistado" bgcolor="#CCCCCC">CURRICULUMS</td>
	</tr>
	<tr> 
		<td width="140" style="padding: 5px" class="textolistado" bgcolor="#F7F7F7"><a href="listado_curriculums.php" class="textolistado" style="text-decoration: none">CURRICULUMS</a></td>

	</tr>
</table>

<br>


<table width="140" border="0" cellspacing="1" cellpadding="0" bgcolor="#999999">
<tr> 
<td width="140" style="padding: 5px" class="textolistado" bgcolor="#FFFFFF"> 
<a href="index.php?cerrar=t" class="textolistado" style="text-decoration: none">LOG-OUT</a></td>
</tr>
</table>