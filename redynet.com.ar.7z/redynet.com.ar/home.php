<?require_once('include/conn.php');?>
<?require_once('include/seguridad.php');?>

<html>
<head>
<title>Redynet IAS | Control Panel</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<link rel='stylesheet' href='include/estilos.css' type='text/css'>
</head>

<body leftmargin='0' topmargin='0' marginwidth='0' marginheight='0'>
<table width='750' height='300' border='0' cellpadding='0' cellspacing='0'>
<tr> 
<td width='140' valign='top' background='images/fondo_cuerpo.gif'> 
<?php require_once('include/naveg.php'); ?>
</td>
<td width='20' background='images/fondo_cuerpo.gif' class='navadmins'>&nbsp;</td>
<td valign='top' background='images/fondo_cuerpo.gif'>


<br>
<br>
<table width='450' height='100' border='0' cellpadding='2' cellspacing='1' bgcolor='#CCCCCC'>
<tr>
<td bgcolor='#FFFFFF'>
<span class='titulo' align='center'>Bienvenido al modulo de carga de datos</span>
<br><br>
<span class='breadcrumb' align='center'>Utilize la botonera de la izquierda para comenzar</span>
</td>

</tr>
</table>

</td>
</tr>
</table>
</body>
</html>